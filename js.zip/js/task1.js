let army = {
    minAge: 18,
    maxAge: 27,
    canJoin(user){
        return user.age >= this.minAge && user.age < this.maxAge;
    }
};

let users = [
    {age: 16},
    {age: 20},
    {age: 23},
    {age: 30}
];

let soilders = users.filter(army.canJoin, army);

console.log("Eligible candidiates are:", soilders.length);
console.log("1st candidiate age is:", soilders[0].age);
console.log("2nd candidiate age is:", soilders[1].age);