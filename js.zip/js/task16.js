let str = "Hello";

let chars = [];

for (let char of str){
    chars.push(char);
}
console.log(chars);
console.log(str);