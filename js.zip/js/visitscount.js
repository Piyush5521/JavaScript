let john = {name: 'John'};
let ben = {name: 'Ben'};

let visitsCountObj = {};

visitsCountObj[ben] =123;
visitsCountObj[john] = 345;

alert(visitsCountObj[ben]); 