loadScript('/script.js', function(){    
    newFunction();    
});
