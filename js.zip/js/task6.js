let arr = [5, 2, 1, -10, 8];

// let dec = arr.sort((a, b)=> {
//     if(a >b) return -1;
//     if(a == b) return 0;
//     if(a < b) return 1;
// })

arr.sort((a, b) => b - a);

console.log(arr);