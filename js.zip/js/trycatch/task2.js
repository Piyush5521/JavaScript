function parseJSON(input){

    try{
        const parsedObject = JSON.parse(input);
        return parsedObject;
    }

    catch (err){
        return ("String is not JSON" + "\n" + err.name + " " + err.message);
    }

}

console.log(parseJSON('{"name": "john", "age": 30}'));
console.log(parseJSON('{"name": "john", age: "30"}'));