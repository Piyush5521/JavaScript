function divideNumbers(a, b) {
  try {

    if(b === 0){
        return (err);
    }

    return a / b;

} catch (err) {

    return ("Cannot divide by zero");

}
}

console.log(divideNumbers(20, 5));  
console.log(divideNumbers(4, 0));
