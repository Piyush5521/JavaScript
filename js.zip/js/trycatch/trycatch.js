try {

    console.log('Stary try block');
    
    lalala;
    
    console.log('End the try block');
}

catch (err) {
    console.log('Catch block!');
}