(async () => {
    let response = await fetch('https://jsonplaceholder.typicode.com/users/1');
    
    let user1 = await response.json();
    console.log("Username: " + user1.username + "\n" + "Email: " + user1.email );
}) ();