function findMax(input){

    try{
        if (Array.isArray(input) === false){
            throw new Error("Input is not array");
        }
        else if(input == 0){
            throw new Error("Array is Empty");
        }
        else if (!(typeof input === 'number')){
            throw new Error("Array contains non-numeric values");
        }

        else {
            return (Math.max(...input));
        }
    }
    catch(err){
        return `Error: ${err.message}`;
    }
}

console.log(findMax([1, 5, 10, 3]));
console.log(findMax([]));
console.log(findMax("Hello"));
console.log(findMax([1, 2, "three"]));