
let mergedArr = [1, 2, 3, 4, 5, 6, 'a', 'b', 'c', 'd', '@', '$'];

let numbers = [];
let strings = [];
let symbols = [];

for (let i = 0; i < mergedArr.length; i ++){
    if(typeof mergedArr[i] === 'number'){
        numbers.push(mergedArr[i]);
    }
    else if(typeof mergedArr[i] === 'string' && /[$\@]/.test(mergedArr[i])){
        strings.push(mergedArr[i]);
    }
    else{
        symbols.push(mergedArr[i]);
    }
}

console.log("Numbers: ", numbers);
console.log("symbols: ", strings);
console.log("Strings: ", symbols);