let recipeMap = new Map([
    ['Cucumber', 500],
    ['Tomatoes', 350],
    ['Onions', 50]
])

recipeMap.forEach((value, key, map) => {
    alert(`${key}: ${value} gram`);
});