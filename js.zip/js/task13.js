let str = '𝒳😂';
for (let char of str) {
    console.log(char);
}