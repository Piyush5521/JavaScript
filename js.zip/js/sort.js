// function compareFn(a, b){
//     if (a > b) return -1;
//     if (a == b) return 0;
//     if (a < b) return 1;
// }

// let arr = [3, 100, 1, 5, 25, 10]


// arr.sort((a, b) =>{
//     if (a > b) return 1;
//     if (a == b) return 0;
//     if (a < b) return -1;
// })

// arr.sort((a, b)=> a-b);


// let str = ['Österreich', 'Andorra', 'Vietnam']
// str.sort((a, b)=> a.localeCompare(b));
// console.log(str)


// let arr = [1, 2, 3, 4, 5];

// arr.sort((a,b)=>{
//     if(a > b) return -1;
//     if(a == b) return 0;
//     if(a < b) return 1;
// })
// // arr.reverse();
// console.log(arr);


let arr = ['hi', 'hello', 'this', 'a'];

let str = arr.join("");
console.log(str);