let obj = {
    name: 'john',
    age: 30
};

let map = new Map((Object.entries(obj)));

alert(map.get('name'));