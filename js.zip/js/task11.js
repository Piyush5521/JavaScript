let arr = [1, 2, 3];

function shuffle(arr){
    let a = arr.random();
    return a;
};

shuffle(arr);