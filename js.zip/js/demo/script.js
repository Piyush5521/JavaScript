// (async () => {
//   let response = await fetch(
//     "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS0mo1-1RPPCSd54lH3fcOeOWM1wRHxEZ3C1A&s"
//   );

//   console.log(response);

//   let blob = await response.blob(); // download as Blob object
//   console.log(blob);
//   // create <img> for it

//   let img = document.createElement("img");

//   console.log(img);

//   img.style = "position:fixed;top:10px;left:10px;width:100px";
//   document.body.append(img);
//   // show it
//   img.src = URL.createObjectURL(blob);

//   setTimeout(() => {
//     // hide after three seconds
//     img.remove();
//     URL.revokeObjectURL(img.src);
//   }, 3000);

//   console.log(blob);
// })();

(async () => {
  let response = await fetch(
    "https://api.github.com/repos/javascript-tutorial/en.javascript.info/commits"
  );

  let text = await response.text(); // read response body as text

  console.log(text.slice(0, 80) + "...");
})();
