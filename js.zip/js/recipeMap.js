let recipeMap = new Map([
    ['cucumber', 500],
    ['tomatoes', 350],
    ['onions', 50]
])

for (let vegetables of recipeMap.keys()){
    alert(vegetables);
}

console.log("\n");

for ( let amount of recipeMap.values()){
    alert(amount);
}

console.log("\n");

for(let entry of recipeMap){
    alert(entry);
}