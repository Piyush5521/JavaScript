let str = "Hello";

// for(let char of str) alert(char);

let char = Array.from(str);
alert(char, "\n");
alert(char[0]);
alert(char[1]);
alert(char[2]);
alert(char[3]);
alert(char[4], "\n");
alert(char.length);